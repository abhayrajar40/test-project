<template>
  <q-form ref="form" class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="Id" />
      <q-input v-model="formData.user_created" label="User Created" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.date_created" label="Date Created" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.user_updated" label="User Updated" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.date_updated" label="Date Updated" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.item_id" label="Item Id"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.rate" label="Rate" :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.quantity" label="Quantity"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.amount" label="Amount" :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.tax_rate" label="Tax Rate"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.tax_amount" label="Tax Amount"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.total_amount" label="Total amount"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.status" label="Status" :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.invoice_id" label="Invoice Id"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.description" label="Description"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
  </q-form>
</template>
<script>
import { date } from "quasar";
export default {
  data() {
    return {
      formData: {},
    };
  },
  methods: {
    validationDateMandatory(val) {
      return !!val || "Required Field";
    },
    validateDateFuture(val) {
      let today = new Date();
      let valDate = new Date(val);
      let dateDiff = date.getDateDiff(today, valDate);
      let validation = "Date must be Tommorrow";
      if (dateDiff < 0) {
        validation = true;
      }
      return validation;
    },
    async submitData() {
      let validation = await this.$refs.form.validate();
      if (!validation) {
        alert("invalid from");
        return;
      }
      console.log("Emitting Event of submitting form with data");
      alert();
      this.$emit("formSubmit", this.formData);
      console.log("Resetting Form");
      alert();
      this.formData = {};
    },
  },
};
</script>
-
