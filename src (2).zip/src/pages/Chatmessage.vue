<template>
  <div class="q-pa-md row justify-center">
    <div style="width: 100%; max-width: 400px">
      <q-chat-message :text="['hey,how are you?']" sent />
      <q-chat-message :text="['doing fine,how are you?']" />
    </div>
  </div>
</template>
