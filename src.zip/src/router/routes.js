
const routes = [
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Indexpage.vue') },
      { path:  'buttons' , component: () => import('pages/Buttons.vue') },
      { path:  'input' , component: () => import('pages/input.vue') },
      { path:  'card' , component: () => import('pages/card.vue') }
    ]
  },
  {
    path: '/modules',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
         path: ':moduleName/:mode?',
       component: () => import('src/pages/Module.vue'),
       props: true
    },

    ]
  },


  // Always leave this as last one,
  // but you can also remove it
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue')
  }
]

export default routes
