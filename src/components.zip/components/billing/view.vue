<template>
  <div class="q-pa-md">
    <div>
      <router-view></router-view>
      <h5>Customer Bills</h5>
    </div>
    <q-table>

    </q-table>
  </div>
</template>

<script>
export default {

}

</script>
