<template>
  <q-card class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="Id" />
      <q-input v-model="formData.account_id" label="Account Id" />
      <q-input v-model="formData.contact_id" label="Contact Id" />
      <q-input v-model="formData.vehicle_id" label="Vehicle Id" />
      <q-input v-model="formData.driver_id" label="Driver Id" />
      <q-input v-model="formData.contract_id" label="Contract Id" />
      <q-input v-model="formData.contact_id" label="Log Type" />
      <q-input v-model="formData.date_from" label="Date From" />
      <q-input v-model="formData.date_to" label="Date To" />
      <q-input v-model="formData.rent" label="Rent" />
      <q-input v-model="formData.initial_reading" label="Initial Reading" />
      <q-input v-model="formData.final_reading" label="Final Reading" />
      <q-input v-model="formData.running_kms" label="Running Kms" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
</q-card>
</template>
<script>
export default {
  data() {
    return {
      formData: {}
    }
  },
  methods: {
    submitData() {
      console.log('Emitting Event of submitting form with data')
      alert()
      this.$emit('formSubmit', this.formData)
      console.log('Resetting Form')
      alert()
      this.formData = {}
    }
  }
}
</script>
