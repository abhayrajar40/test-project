<template>
  <q-card class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="Id" />
      <q-input v-model="formData.sort" label="Sort" />
      <q-input v-model="formData.date_created" label="Date Created" />
      <q-input v-model="formData.date_updated" label="Date Updated" />
      <q-input v-model="formData.vehicle_type" label="Vehicle Type" />
      <q-input v-model="formData.vehicles" label="Vehicles" />
      <q-input v-model="formData.contracts" label="Contracts" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
</q-card>
</template>
<script>
export default {
  data() {
    return {
      formData: {}
    }
  },
  methods: {
    submitData() {
      console.log('Emitting Event of submitting form with data')
      alert()
      this.$emit('formSubmit', this.formData)
      console.log('Resetting Form')
      alert()
      this.formData = {}
    }
  }
}
</script>
