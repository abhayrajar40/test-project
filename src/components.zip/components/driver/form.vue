<template>
  <q-card class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="Account Id" :options="id" />
      <q-input v-model="formData.driver_name" label="Driver Name" :options="driver_name" />
      <q-input v-model="formData.address" label="Address" :options="address" />
      <q-input v-model="formData.contact_no" label="Contact Number" />
      <q-select clearable v-model="formData.status" label="Status" :options="['Published', 'Draft', 'Archived']" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
  </q-card>
</template>
<script>
export default {
  data() {
    return {
      formData: {},
    };
  },
  created() {
    this.fetchDriver();
  },
  methods: {
    async fetchDriver() {
      let response = await this.$api.get("items/driver");
      this.driver = response.data.data;
    },
    submitData() {
      console.log("Emitting Event of submitting form with data");
      alert();
      this.$emit("formSubmit", this.formData);
      console.log("Resetting Form");
      alert();
      this.formData = {};
    },
  },
};
</script>
