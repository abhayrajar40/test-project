<template>
  <q-card class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="Id" :options="id" />
      <q-input v-model="formData.sort" label="Sort" />
      <q-select v-model="formData.bank_name" label="Bank Name" :options="banks" option-label="bank_name"
        option-value="bank_name" map-options emit-value />
      <q-select v-model="formData.account_name" label="Account Name" :options="banks" option-label="account_name"
        option-value="account_name" map-options emit-value />
      <q-select v-model="formData.account_no" label="Account Number" :options="banks" option-label="account_no"
        option-value="account_no" map-options emit-value />
      <q-select v-model="formData.ifsc" label="Ifsc" :options="banks" option-label="ifsc" option-value="ifsc" map-options
        emit-value />
      <q-select v-model="formData.branch" label="Branch" :options="banks" option-label="branch" option-value="branch"
        map-options emit-value />
      <q-select v-model="formData.organisation_id" label="Organisation Id" :options="organisation"
        option-label="organisation_name" option-value="id" map-options emit-value />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
  </q-card>
</template>
<script>
export default {
  data() {
    return {
      formData: {},
      organisation: [],
    };
  },
  created() {
    this.fetchOrganisation();
  },
  methods: {
    async fetchOrganisation() {
      let response = await this.$api.get("items/organisation");
      let resp = await this.$api.get("items/banks");
      this.organisation = response.data.data;
      this.banks = resp.data.data;
    },
    submitData() {
      console.log("Emitting Event of submitting form with data");
      alert();
      this.$emit("formSubmit", this.formData);
      console.log("Resetting Form");
      alert();
      this.formData = {};
    },
  },
};
</script>
