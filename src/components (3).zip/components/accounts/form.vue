<template>
  <q-form ref="form" class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input ref="inputref" v-model="formData.account_name" mask="S" reverse-fill-mask label="Account Name*"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.account_address" label="Account Address*" type="text"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input ref="inputref" v-model="formData.contact_number" mask="(###) ### - ####" label="Contact Number" />
      <q-input ref="inputref" v-model="formData.email" mask="x" reverse-fill-mask label="Email" type="email" />
      <q-input ref="inputref" v-model="formData.city" label="City" mask="S" reverse-fill-mask />
      <q-input ref="inputref" v-model="formData.state" label="state" mask="S" reverse-fill-mask />
      <q-input ref="inputref" v-model="formData.pin_code" mask="######" label="Pin Code" />
      <q-input v-model="formData.country" label="Country" />
      <q-input v-model="formData.accounting_receipts" label="Accounting Receipts" />
      <q-input v-model="formData.status" label="Status" />
      <q-input v-model="formData.invoices" label="Invoices" />
      <q-input v-model="formData.contacts" label="Contacts" />
      <q-input v-model="formData.log_book" label="Log Book" />
      <q-input v-model="formData.contracts" label="Contracts" />
      <q-input v-model="formData.gst" label="Gst" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
  </q-form>
</template>
<script>
import { date } from "quasar";
export default {
  data() {
    return {
      formData: {},
    };
  },
  methods: {
    validationDateMandatory(val) {
      return !!val || "Required Field";
    },
    validateDateFuture(val) {
      let today = new Date();
      let valDate = new Date(val);
      let dateDiff = date.getDateDiff(today, valDate);
      let validation = "Date must be Tommorrow";
      if (dateDiff < 0) {
        validation = true;
      }
      return validation;
    },
    async submitData() {
      let validation = await this.$refs.form.validate();
      if (!validate) {
        alert("invalid form");
        return;
      }
      console.log("Emitting Event of submitting form with data");
      alert();
      this.$emit("formSubmit", this.formData);
      console.log("Resetting Form");
      alert();
      this.formData = {};
    },
  },
};
</script>
