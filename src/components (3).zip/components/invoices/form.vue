<template>
  <q-form ref="form" class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="Id" />
      <q-select clearable v-model="formData.account_id" label="Account Id" :options="accounts" option-label="account_name"
        option-value="id" map-options emit-value />
      <q-input v-model="formData.invoice_number" label="Invoices Number"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.invoice_date" type="date" stack-label label="Invoice Date"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.grand_total" label="Grand Total"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-select clearable v-model="formData.invoice_status" label="Invoices Status"
        :options="['Draft', 'Provisional', 'Final', 'Cancelled']"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-select v-model="formData.payment_status" label="Payment Status" :options="['Unpaid', 'Partially Paid', 'Paid']"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.user_created" label="User Created" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.date_created" label="Date Created" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.user_updated" label="User Updated" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-input v-model="formData.date_updated" label="Date Updated" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
      <q-select clearable v-model="formData.organisation_id" label="Organisation Id" :options="organisation"
        option-label="id" option-value="organisation_name" map-options emit-value />
      <q-input v-model="formData.invoice_details" label="Invoice Details"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.invoice_settlement" label="Invoice Settlement"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.period" label="Period" :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.bank_id" label="Bank Id" :options="banks" option-label="id" option-value="bank_name"
        map_options emit-value />
      <q-input v-model="formData.booked_by" label="Booked By"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.oncall_plan" label="Oncall Plan"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.vehicle_no" label="Vehicle No"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.log_type" label="Log Type"
        :rules="[(val) => (val && val.length > 0) || 'Required Field']" />
      <q-input v-model="formData.journey_date" label="Journey Date" type="date" stack-label
        :rules="[validationDateMandatory, validateDateFuture]" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
  </q-form>
</template>
<script>
import { date } from "quasar";
export default {
  data() {
    return {
      formData: {},
      accounts: [],
      organisation: [],
      banks: [],
    };
  },
  created() {
    this.fetchAccounts();
    this.fetchOrganisation();
    this.fetchBanks();
  },
  methods: {
    validationDateMandatory(val) {
      return !!val || "Field is mandatory";
    },
    validateDateFuture(val) {
      let today = new Date();
      let valDate = new Date(val);
      let dateDiff = date.getDateDiff(today, valDate);
      let validation = "Future Date";
      if (dateDiff < 0) {
        validation = true;
      }
      return validation;
    },
    async fetchAccounts() {
      let response = await this.$api.get("items/accounts");
      this.accounts = response.data.data;
    },
    async fetchOrganisation() {
      let response = await this.$api.get("items/organisation");
      this.organisation = response.data.data;
    },
    async fetchBanks() {
      let response = await this.$api.get("items/banks");
      this.banks = response.data.data;
    },
    async submitData() {
      let validation = await this.$refs.form.validate();
      if (!validation) {
        alert("invalid form");
        return;
      }
      console.log("Emitting Event of submitting form with data");
      alert();
      this.$emit("formSubmit", this.formData);
      console.log("Resetting Form");
      alert();
      this.formData = {};
    },
  },
};
</script>
